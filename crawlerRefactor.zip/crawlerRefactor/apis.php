<?php
	$apiBank = array();
?>