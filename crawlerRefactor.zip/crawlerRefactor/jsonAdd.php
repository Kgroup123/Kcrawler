<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="rank2.php?filename=C:\Users\LGP48\Desktop\TEST2\SPA_024_B_1212CC_08_TEST2.xlsx" method="POST">
	
	<input type="submit" name="submit" value="ok">
</form>
</body>
</html>